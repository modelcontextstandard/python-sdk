#!/usr/bin/env python3
"""Network-restricted test harness for MCS Gmail skill.

Simulates Claude Code Desktop's network restrictions by blocking all
outbound HTTP requests except to explicitly allowed hosts.  This
verifies that the Auth0 proxy fix works -- all auth0.com calls must
go through broker.linkauth.io/v1/proxy.

Usage:
    python scripts/test_network_restricted.py exec list_messages '{"limit": 5}'
"""

import json
import sys
from pathlib import Path
from urllib.parse import urlparse

ALLOWED_HOSTS = {
    "broker.linkauth.io",
    "gmail.googleapis.com",
}

_SKILL_DIR = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Monkey-patch HttpAdapter BEFORE any MCS imports
# ---------------------------------------------------------------------------

from mcs.adapter.http import HttpAdapter

_request_log: list[tuple[str, str, str]] = []  # (method, host, url)
_original_request = HttpAdapter.request


def _restricted_request(self, method, url, **kwargs):
    host = urlparse(url).hostname or ""
    _request_log.append((method, host, url))
    print(f"[net] {method} {host} -> {url[:120]}", file=sys.stderr)
    if host not in ALLOWED_HOSTS:
        raise ConnectionError(
            f"BLOCKED by network restriction: {method} {url} "
            f"(host '{host}' not in allowed list: {sorted(ALLOWED_HOSTS)})"
        )
    return _original_request(self, method, url, **kwargs)


HttpAdapter.request = _restricted_request
print(f"[test] Network restriction active. Allowed: {sorted(ALLOWED_HOSTS)}", file=sys.stderr)

# ---------------------------------------------------------------------------
# Now import and run the skill (same as mcs_tool.py)
# ---------------------------------------------------------------------------

sys.path.insert(0, str(_SKILL_DIR / "scripts"))
import mcs_tool  # noqa: E402  -- triggers the auth chain setup

driver = mcs_tool.driver


def _run():
    if len(sys.argv) < 2:
        print("Usage: test_network_restricted.py [status|tools|exec <name> '<json>']")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "status":
        tools = driver.list_tools()
        print(json.dumps({
            "driver": driver.meta.name,
            "version": driver.meta.version,
            "tools": [t.name for t in tools],
        }, indent=2))

    elif cmd == "tools":
        for t in driver.list_tools():
            print(f"{t.name}: {t.description}")

    elif cmd == "exec":
        name = sys.argv[2]
        params = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
        try:
            result = driver.execute_tool(name, params)
        except ConnectionError as exc:
            print(json.dumps({"error": str(exc)}, indent=2), file=sys.stderr)
            sys.exit(1)
        if isinstance(result, (dict, list)):
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(result)
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    _run()
