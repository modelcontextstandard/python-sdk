#!/usr/bin/env python3
"""Stateless two-phase test for MCS Gmail skill.

Simulates Claude Code Desktop: each phase runs in a fresh subprocess.

Usage:
    python test_stateless.py phase1    # Trigger AuthChallenge, verify cache
    # ... user authenticates via link ...
    python test_stateless.py phase2    # Token exchange + Gmail call
    python test_stateless.py phase3    # Verify cached token reuse
    python test_stateless.py clean     # Clear cache for fresh start
"""

import json
import subprocess
import sys
from pathlib import Path

_SKILL_DIR = Path(__file__).resolve().parent.parent
_CACHE_FILE = _SKILL_DIR / ".mcs_token_cache"
_TOOL_SCRIPT = _SKILL_DIR / "scripts" / "mcs_tool.py"

_RESTRICTED_RUNNER = r'''
import json, sys
from urllib.parse import urlparse

ALLOWED_HOSTS = {"broker.linkauth.io", "gmail.googleapis.com"}

from mcs.adapter.http import HttpAdapter
_orig = HttpAdapter.request

def _patched(self, method, url, **kw):
    host = urlparse(url).hostname or ""
    print(f"  [net] {method} {host} -> {url[:120]}", file=sys.stderr)
    if host not in ALLOWED_HOSTS:
        raise ConnectionError(f"BLOCKED: {method} {url} (host '{host}' not allowed)")
    return _orig(self, method, url, **kw)

HttpAdapter.request = _patched

sys.argv = __ARGV__
__file__ = __SCRIPT__
exec(compile(open(__SCRIPT__).read(), __SCRIPT__, "exec"))
'''


def _run_subprocess(argv: list[str]) -> tuple[int, str, str]:
    code = _RESTRICTED_RUNNER.replace(
        "__ARGV__", repr(argv),
    ).replace(
        "__SCRIPT__", repr(str(_TOOL_SCRIPT)),
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True, text=True, timeout=30, cwd=str(_SKILL_DIR),
    )
    return result.returncode, result.stdout, result.stderr


def _read_cache() -> dict:
    if not _CACHE_FILE.exists():
        return {}
    return json.loads(_CACHE_FILE.read_text(encoding="utf-8"))


def phase1():
    print("=" * 60)
    print("  PHASE 1: First subprocess (expect AuthChallenge)")
    print("=" * 60)

    exit_code, stdout, stderr = _run_subprocess(
        ["mcs_tool.py", "exec", "list_messages", '{"limit": 5}'],
    )
    print(f"\n  Exit code: {exit_code}")
    if stderr:
        print(f"  STDERR:\n{stderr.rstrip()}")

    assert exit_code != 0, "FAIL: Phase 1 should exit non-zero"
    assert "AuthChallenge" in stderr, "FAIL: Should raise AuthChallenge"
    print("\n  [PASS] AuthChallenge raised as expected")

    cache = _read_cache()
    print(f"\n  Cache keys: {sorted(cache.keys())}")

    assert "linkauth:privkey" in cache, "FAIL: RSA key not cached"
    print("  [PASS] RSA private key cached")

    assert "linkauth:sessions" in cache, "FAIL: Session not cached"
    sessions = json.loads(cache["linkauth:sessions"]["v"])
    session = next(iter(sessions.values()))
    print(f"  [PASS] Session cached: {session.get('url')}")

    print(f"\n  >>> Authenticate now: {session.get('url')}")
    print(f"  >>> Then run: python {Path(__file__).name} phase2")


def phase2():
    print("=" * 60)
    print("  PHASE 2: Second subprocess (token exchange + Gmail)")
    print("=" * 60)

    cache_before = _read_cache()
    assert "linkauth:sessions" in cache_before, \
        "FAIL: No session in cache. Run phase1 first."

    exit_code, stdout, stderr = _run_subprocess(
        ["mcs_tool.py", "exec", "list_messages", '{"limit": 5}'],
    )
    print(f"\n  Exit code: {exit_code}")
    if stderr:
        print(f"  Network log:\n{stderr.rstrip()}")

    # Check for auth0.com leak
    for line in stderr.splitlines():
        if "[net]" in line and "auth0" in line.lower():
            if "broker.linkauth.io" not in line:
                print(f"\n  [FAIL] Direct auth0.com call: {line}")
                sys.exit(1)
    print("\n  [PASS] No direct auth0.com calls")

    cache_after = _read_cache()
    has_rt = any(k.startswith("rt:") for k in cache_after)
    has_at = any(k.startswith("at:") for k in cache_after)
    print(f"  [{'PASS' if has_rt else 'FAIL'}] Refresh token cached: {has_rt}")
    print(f"  [{'PASS' if has_at else 'FAIL'}] Access token cached:  {has_at}")

    if exit_code == 0:
        try:
            messages = json.loads(stdout)
            print(f"  [PASS] Got {len(messages)} messages from Gmail")
        except (json.JSONDecodeError, TypeError):
            print(f"  [WARN] Output: {stdout[:200]}")
        print(f"\n  >>> Run: python {Path(__file__).name} phase3")
    else:
        print(f"\n  [FAIL] Phase 2 failed!")
        if stdout:
            print(f"  STDOUT:\n{stdout[:500]}")
        sys.exit(1)


def phase3():
    print("=" * 60)
    print("  PHASE 3: Third subprocess (cached token reuse)")
    print("=" * 60)

    cache_before = _read_cache()
    has_at = any(k.startswith("at:") for k in cache_before)
    assert has_at, "FAIL: No access token in cache. Run phase2 first."

    exit_code, stdout, stderr = _run_subprocess(
        ["mcs_tool.py", "exec", "list_messages", '{"limit": 2}'],
    )
    print(f"\n  Exit code: {exit_code}")
    if stderr:
        print(f"  Network log:\n{stderr.rstrip()}")

    # Phase 3 should NOT need the proxy (token from cache)
    has_proxy_call = "broker.linkauth.io/v1/proxy" in stderr
    print(f"\n  [{'WARN' if has_proxy_call else 'PASS'}] "
          f"Token exchange skipped (served from cache): {not has_proxy_call}")

    if exit_code == 0:
        try:
            messages = json.loads(stdout)
            print(f"  [PASS] Got {len(messages)} messages from Gmail")
        except (json.JSONDecodeError, TypeError):
            pass
        print("\n" + "=" * 60)
        print("  ALL PHASES PASSED")
        print("=" * 60)
    else:
        print(f"\n  [FAIL] Phase 3 failed!")
        sys.exit(1)


def clean():
    if _CACHE_FILE.exists():
        _CACHE_FILE.unlink()
        print("Cache cleared.")
    else:
        print("No cache file found.")


if __name__ == "__main__":
    cmds = {"phase1": phase1, "phase2": phase2, "phase3": phase3, "clean": clean}
    if len(sys.argv) < 2 or sys.argv[1] not in cmds:
        print(f"Usage: {Path(__file__).name} [{'/'.join(cmds)}]")
        sys.exit(1)
    cmds[sys.argv[1]]()
